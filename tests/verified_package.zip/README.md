# 🕷️ scraper (www.stockq.org)

Target: https://www.stockq.org/market/asia.php

## 🚀 How to Run

### Method 1: Using `uv` (Recommended)
If you have `uv` installed (modern Python package manager), it will automatically create a virtual environment and run safely without polluting your system.

**Double-click `run.bat`**

### Method 2: Standard Python
If you don't have `uv`, `run.bat` will fall back to standard `pip install` + `python`.

## 📅 Auto-Scheduling

To run this scraper every day at 09:00 AM:

1.  **Right-click `setup_task.bat`**
2.  Select **"Run as Administrator"** (Required for Task Scheduler)
3.  Follow the prompts.

## 📂 Output
Results will be saved to `result.txt` in the same folder.
