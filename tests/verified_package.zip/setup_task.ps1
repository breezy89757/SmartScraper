$TaskName = "SmartScraper-www_stockq_org"
$ScriptPath = "$PSScriptRoot\scraper.py"

# 檢查 uv
$UVPath = (Get-Command uv -ErrorAction SilentlyContinue).Source
$PythonPath = (Get-Command python -ErrorAction SilentlyContinue).Source

if ($UVPath) {
    $ExePath = "cmd.exe"
    # 注意: Windows 排程器 Argument 需要非常小心的跳脫引號
    # 我們希望執行: cmd /c "uv run "ScriptPath" > result.txt 2>&1"
    $Args = "/c uv run `"$ScriptPath`" > result.txt 2>&1"
    Write-Host "Using 'uv' for execution." -ForegroundColor Cyan
} elseif ($PythonPath) {
    $ExePath = "cmd.exe"
    $Args = "/c python `"$ScriptPath`" > result.txt 2>&1"
    Write-Host "Using 'python' for execution (Global Env)." -ForegroundColor Yellow
} else {
    Write-Error "Neither 'uv' nor 'python' found in PATH."
    exit 1
}

$Action = New-ScheduledTaskAction -Execute $ExePath -Argument $Args -WorkingDirectory $PSScriptRoot
$Trigger = New-ScheduledTaskTrigger -Daily -At 9am
Register-ScheduledTask -Action $Action -Trigger $Trigger -TaskName $TaskName -Description "Daily SmartScraper execution for https://www.stockq.org/market/asia.php" -Force

Write-Host "Task '$TaskName' registered successfully to run daily at 9:00 AM." -ForegroundColor Green
Write-Host "Logs will be saved to: $PSScriptRoot\result.txt" -ForegroundColor Gray
